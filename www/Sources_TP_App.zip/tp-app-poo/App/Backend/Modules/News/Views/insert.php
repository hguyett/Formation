<h2>Ajouter une news</h2>
<form action="" method="post">
  <p>
    <?= $form ?>
    
    <input type="submit" value="Ajouter" />
  </p>
</form>