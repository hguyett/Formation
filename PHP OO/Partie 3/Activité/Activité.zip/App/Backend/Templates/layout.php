<?php
require realpath(__DIR__ . '/../../Frontend/Templates/layout.php');
