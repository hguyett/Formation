<h2>Modifier une news</h2>
<form action="" method="post">
  <p>
    <?php echo $form ?>

    <input type="submit" value="Modifier" />
  </p>
</form>
