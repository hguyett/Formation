<h2>Modifier un commentaire</h2>
<form action="" method="post">
  <p>
    <?php echo $form ?>

    <input type="submit" value="Modifier" />
  </p>
</form>
