<h2>Connexion</h2>

<form action="" method="post">
    <label for="login">Pseudo</label>
    <input type="text" name="login">
    <label for="password">Mot de passe</label>
    <input type="text" name="password">
    <br>
    <br>
    <input type="submit" value="Connexion">
</form>
